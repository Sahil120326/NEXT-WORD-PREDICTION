import re
from typing import List

_TOKEN_RE = re.compile(r"\b\w+'\w+|\w+\b", re.UNICODE)

def tokenize(text: str) -> List[str]:
    """Very simple word tokenizer (lowercased, keeps contractions).
    Example: "I'm testing this." -> ["i'm", 'testing', 'this']
    """
    text = text.lower()
    return _TOKEN_RE.findall(text)
