from __future__ import annotations
from collections import Counter, defaultdict, deque
from typing import Dict, Iterable, List, Sequence, Tuple
from functools import lru_cache

class NGramModel:
    def __init__(self, n: int = 3):
        assert n >= 1
        self.n = n
        self.ngram_counts: Dict[Tuple[str, ...], int] = Counter()
        self.context_counts: Dict[Tuple[str, ...], int] = Counter()
        self.vocab: set[str] = set()
        self.context_predictions: Dict[Tuple[str, ...], List[Tuple[str, float]]] = {}
        self.common_words: List[Tuple[str, float]] = []

    def fit(self, tokens: Iterable[str]) -> None:
        """Train n-gram counts with simple add-one (Laplace) smoothing support."""
        window = deque(maxlen=self.n)
        for tok in tokens:
            self.vocab.add(tok)
            window.append(tok)
            if len(window) == self.n:
                ngram = tuple(window)
                self.ngram_counts[ngram] += 1
                context = ngram[:-1]
                self.context_counts[context] += 1
        
        # Precompute common words for fallback (much faster!)
        print("  → Precomputing common words...")
        word_freq = defaultdict(int)
        for ng in self.ngram_counts:
            word_freq[ng[-1]] += self.ngram_counts[ng]
        total = sum(word_freq.values())
        self.common_words = sorted(
            [(w, freq / total) for w, freq in word_freq.items()],
            key=lambda x: x[1],
            reverse=True
        )[:50]  # Keep top 50 common words

    def predict(self, prefix: Sequence[str], top_k: int = 5, partial_word: str = '') -> List[Tuple[str, float]]:
        """Return top_k next-word candidates given prefix.
        prefix: completed words
        partial_word: incomplete word being typed (for autocomplete)
        """
        if not self.vocab:
            return []
        
        # If user is typing a partial word, complete it first
        if partial_word:
            completions = []
            partial_lower = partial_word.lower()
            for word in self.vocab:
                if word.startswith(partial_lower) and word != partial_lower:
                    # Get frequency of this word
                    freq = sum(cnt for ng, cnt in self.ngram_counts.items() if ng[-1] == word)
                    completions.append((word, freq))
            
            # Sort by frequency and return top matches
            completions.sort(key=lambda x: x[1], reverse=True)
            results = [(w, 1.0) for w, _ in completions[:top_k]]
            return results if results else []
        
        # Predict next word based on context
        k = self.n - 1
        contexts_to_try = []
        
        if len(prefix) >= k:
            contexts_to_try.append(tuple(prefix[-k:]))  # Full context
        if k > 1 and len(prefix) >= 1:
            contexts_to_try.append(tuple(prefix[-1:]))  # Single word
        
        # Try each context
        for ctx in contexts_to_try:
            if ctx in self.context_predictions:
                return self.context_predictions[ctx][:top_k]
            
            candidates = defaultdict(int)
            if ctx:
                for ng, cnt in self.ngram_counts.items():
                    if ng[:-1] == ctx:
                        candidates[ng[-1]] += cnt
            
            if candidates and len(candidates) >= 3:  # Need at least 3 good predictions
                scored = sorted(candidates.items(), key=lambda x: x[1], reverse=True)
                result = [(w, cnt) for w, cnt in scored[:top_k]]
                total = sum(cnt for _, cnt in result)
                result = [(w, cnt / total) for w, cnt in result]
                self.context_predictions[ctx] = result
                return result
        
        # Fallback to common words (only if no context matches)
        return self.common_words[:top_k]
