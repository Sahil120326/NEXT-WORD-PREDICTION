import sys
from pathlib import Path
import click

from .tokenizer import tokenize
from .model import NGramModel

@click.command()
@click.option('--corpus', type=click.Path(exists=False, dir_okay=False), default='data/corpus.txt', help='Path to plain-text corpus file')
@click.option('--n', 'n_val', type=int, default=3, show_default=True, help='N for the n-gram model')
@click.option('--top-k', type=int, default=5, show_default=True, help='Number of suggestions to return')
def main(corpus: str, n_val: int, top_k: int):
    """Interactive next-word prediction demo using a simple n-gram model."""
    corpus_path = Path(corpus)
    if corpus_path.exists():
        text = corpus_path.read_text(encoding='utf-8', errors='ignore')
    else:
        click.echo(f'Corpus not found at {corpus_path}. Using a tiny built-in sample.\n')
        text = """
        i love machine learning and natural language processing
        i love coding in python and building language models
        language models can predict the next word
        gboard predicts the next word while typing on the phone
        """
    tokens = tokenize(text)
    model = NGramModel(n=n_val)
    model.fit(tokens)

    click.echo('Model ready. Type a prefix (blank line to exit).')
    while True:
        try:
            prefix = input('> ').strip()
        except EOFError:
            break
        if not prefix:
            break
        preds = model.predict(tokenize(prefix), top_k=top_k)
        if not preds:
            click.echo('(no suggestions)')
        else:
            click.echo(', '.join(f"{w} ({p:.3f})" for w, p in preds))

if __name__ == '__main__':
    main()
